import sys
sys.path.append('recursos/')

from mazos import MazoBlackJack
from cartas import CartaPoker
