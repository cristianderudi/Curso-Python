

from abc import ABC,abstractmethod

class Fruta(ABC):
    def __init__(self,nombre) -> None:
        self.nombre = nombre

    def __str__(self) -> str:
        return "soy "+self.nombre
    
    @abstractmethod
    def pelar(self):
        pass


class Banana(Fruta):
    def __init__(self) -> None:
        super().__init__("Banana")

    def pelar(self):
        print("pelando "+ str(self))


class Naranja(Fruta):
    def __init__(self) -> None:
        super().__init__("Naranja")        

    def pelar(self):
        print("pelando "+ str(self))


class NaranjaJoya(Naranja):
    def __init__(self) -> None:
        super().__init__()

        

class Pera(Fruta):
    def __init__(self) -> None:
        super().__init__("Pera")

    def pelar(self):
        print("pelando "+ str(self))


def main():
    f = NaranjaJoya()
    print(f)

    p = Pera()
    p.pelar()
main()









