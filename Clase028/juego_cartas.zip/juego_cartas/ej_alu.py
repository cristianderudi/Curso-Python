import json
path = "defaultjson.json"
try:
    with open(path,mode='r+', encoding='utf-8') as archivo:
        try:
            datos_diccionario = json.load(archivo)
            if datos_diccionario['bot_enabled'] == "True":
                datos_diccionario['bot_enabled'] = "False"
                print("Disabled!")
            elif datos_diccionario['bot_enabled'] == "False":
                print("Already disabled!")
        except Exception as ex:
            raise Exception(f"Error after processing [open path] {ex}\n")
            
    with open(path,mode='w', encoding='utf-8') as file:
        try:
            json.dump(datos_diccionario, file, ensure_ascii=False, indent=4)
        except Exception as ex:
            raise Exception(f"Error: {ex}\n")
except Exception as ex:
    raise Exception(f"{ex}\n")